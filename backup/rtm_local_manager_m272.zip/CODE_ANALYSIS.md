# RTM Local Manager 코드 분석 보고서

## 1. 프로젝트 개요

**RTM Local Manager**는 JIRA + Deviniti RTM for Jira (Data Center) 환경에서 요구사항/테스트/결함 이슈를 로컬 SQLite DB와 Excel로 연동·관리하는 데스크톱 애플리케이션입니다.

### 기술 스택
- **언어**: Python 3.12
- **GUI 프레임워크**: PySide6 (Qt6)
- **데이터베이스**: SQLite3
- **외부 라이브러리**: requests, openpyxl (Excel 처리)

### 실행 구조
```
main.py
  └─> gui.main_window.run()
       └─> MainWindow(db_path, config_path, mode="both")
            └─> QApplication.exec() (이벤트 루프)
```

---

## 2. 디렉터리 구조

```
rtm_local_manager/
├── main.py                    # 엔트리 포인트
├── requirements.txt           # 의존성 (PySide6, requests)
├── jira_config.json          # JIRA 설정 파일
├── rtm_local.db              # SQLite 데이터베이스
│
├── backend/                  # 백엔드 로직
│   ├── __init__.py
│   ├── db.py                 # SQLite 스키마 및 DAO
│   ├── jira_api.py           # JIRA/RTM REST API 클라이언트
│   ├── jira_mapping.py       # JIRA JSON ↔ 로컬 DB 매핑
│   ├── excel_io.py           # Excel Import/Export
│   ├── excel_mapping.py      # Excel 컬럼 매핑 설정
│   ├── bulk_create.py        # 대량 이슈 생성
│   ├── sync.py               # 트리 동기화 로직
│   ├── logger.py             # 로깅 유틸리티
│   ├── field_presets.py      # 필드 프리셋 관리
│   ├── local_settings.py     # 로컬 설정 관리
│   └── attachments_fs.py     # 첨부파일 파일시스템 관리
│
└── gui/                      # GUI 컴포넌트
    ├── __init__.py
    ├── main_window.py        # 메인 윈도우 (약 10,000줄)
    ├── create_issue_dialog.py # 온라인 이슈 생성 다이얼로그
    └── bulk_create_dialog.py  # 대량 생성 진행 다이얼로그
```

---

## 3. 핵심 모듈 상세 분석

### 3.1. `backend/db.py` - 데이터베이스 레이어

#### 주요 테이블 구조

1. **projects** - 프로젝트 정보
   - `id`, `project_key`, `project_id`, `name`, `base_url`, `rtm_version`

2. **folders** - 폴더 계층 구조
   - `id` (TEXT PK), `project_id`, `parent_id`, `name`, `node_type`, `sort_order`

3. **issues** - 이슈 메인 테이블
   - 기본 필드: `id`, `project_id`, `jira_key`, `jira_id`, `issue_type`, `summary`, `description`
   - 상태/우선순위: `status`, `priority`, `assignee`, `reporter`
   - 메타데이터: `labels`, `components`, `fix_versions`, `affects_versions`
   - RTM 특화: `rtm_environment`, `preconditions`, `epic_link`, `sprint`
   - 관계: `folder_id`, `parent_issue_id`
   - 플래그: `is_deleted`, `local_only`, `dirty`, `last_sync_at`

4. **testcase_steps** - Test Case 단계
   - `id`, `issue_id`, `group_no`, `order_no`, `action`, `input`, `expected`

5. **testplan_testcases** - Test Plan ↔ Test Case 매핑
   - `id`, `testplan_id`, `testcase_id`, `order_no`

6. **testexecutions** - Test Execution 메타
   - `id`, `issue_id`, `environment`, `start_date`, `end_date`, `result`, `executed_by`

7. **testcase_executions** - Test Case Execution
   - `id`, `testexecution_id`, `testcase_id`, `order_no`, `assignee`, `result`, `actual_time`, `rtm_environment`, `defects`, `tce_test_key`

8. **testcase_step_executions** - Step Execution
   - `id`, `testcase_execution_id`, `testcase_step_id`, `status`, `actual_result`, `evidence`

9. **relations** - 이슈 간 관계
   - `id`, `src_issue_id`, `dst_issue_id`, `relation_type`, `created_at`

10. **sync_state** - 동기화 상태 추적
    - `id`, `project_id`, `last_full_sync_at`, `last_tree_sync_at`, `last_issue_sync_at`

#### 주요 함수
- `init_db()`: 스키마 초기화 및 마이그레이션
- `get_or_create_project()`: 프로젝트 조회/생성
- `create_local_issue()`: 로컬 이슈 생성
- `update_issue_fields()`: 이슈 필드 업데이트
- `fetch_folder_tree()`: 폴더/이슈 트리 구조 조회
- `get_steps_for_issue()`, `replace_steps_for_issue()`: Test Case Steps 관리
- `get_testplan_testcases()`, `replace_testplan_testcases()`: Test Plan-Test Case 매핑
- `get_testcase_executions()`, `replace_testcase_executions()`: Test Execution 관리

---

### 3.2. `backend/jira_api.py` - JIRA/RTM REST API 클라이언트

#### 주요 클래스

**`JiraConfig`** (dataclass)
- `base_url`, `username`, `api_token`, `project_key`, `project_id`, `endpoints` (Dict)

**`JiraRTMClient`**
- JIRA/RTM REST API를 래핑하는 클라이언트
- Personal Access Token 기반 인증
- 엔드포인트 템플릿 시스템 (설정 파일에서 커스터마이징 가능)

#### 주요 메서드

**트리 조회**
- `get_tree(tree_type: str)`: RTM 트리 구조 조회 (requirements, test-cases, test-plans, test-executions, defects)

**엔티티 CRUD**
- `get_entity(issue_type: str, jira_key: str)`: 개별 이슈 조회
- `create_entity(issue_type: str, payload: Dict)`: 이슈 생성
- `update_entity(issue_type: str, jira_key: str, payload: Dict)`: 이슈 업데이트
- `delete_entity(issue_type: str, jira_key: str)`: 이슈 삭제

**Test Case 관련**
- `get_testcase_steps(jira_key: str)`: Test Case Steps 조회
- `update_testcase_steps(jira_key: str, payload: Dict)`: Steps 업데이트

**Test Plan 관련**
- `get_testplan_testcases(jira_key: str)`: Test Plan에 포함된 Test Cases 조회
- `update_testplan_testcases(jira_key: str, payload: Dict)`: Test Cases 업데이트

**Test Execution 관련**
- `execute_test_plan(testplan_key: str, payload: Optional[Dict])`: Test Plan 실행하여 Test Execution 생성
- `get_testexecution_details(jira_key: str)`: Test Execution 상세 조회

**JIRA 표준 API**
- `get_jira_issue(jira_key: str)`: JIRA 표준 이슈 조회
- `get_jira_comments(jira_key: str)`: 댓글 조회
- `add_jira_comment(jira_key: str, body: str)`: 댓글 추가
- `search_jira(jql: str)`: JQL 검색

#### 엔드포인트 관리
- `DEFAULT_ENDPOINTS`: 기본 엔드포인트 템플릿 딕셔너리
- `jira_config.json`의 `endpoints` 섹션에서 오버라이드 가능
- 세미콜론(`;`)으로 여러 후보 엔드포인트 지정 가능 (자동 fallback)

---

### 3.3. `backend/jira_mapping.py` - 데이터 매핑 레이어

#### 주요 기능

**Pull 매핑 (JIRA/RTM → 로컬 DB)**
- `map_jira_to_local()`: JIRA 표준 이슈 → 로컬 issues 테이블
- `map_rtm_to_local()`: RTM 이슈 → 로컬 issues 테이블 (이슈 타입별 전용 함수)
  - `map_rtm_requirement_to_local()`: Requirement
  - `map_rtm_testcase_to_local()`: Test Case (Steps, Preconditions 포함)
  - `map_rtm_testplan_to_local()`: Test Plan (includedTestCases 포함)
  - `map_rtm_testexecution_to_local()`: Test Execution (testCaseExecutions 포함)
  - `map_rtm_defect_to_local()`: Defect (identifyingTestCases 포함)

**Push 매핑 (로컬 DB → JIRA/RTM API)**
- `build_rtm_payload()`: 로컬 이슈 → RTM API payload (이슈 타입별 전용 함수)
  - `build_rtm_requirement_payload()`
  - `build_rtm_testcase_payload()` (Steps 포함)
  - `build_rtm_testplan_payload()` (includedTestCases 포함)
  - `build_rtm_testexecution_payload()` (testCaseExecutions 포함)
  - `build_rtm_defect_payload()`

**Steps 매핑**
- `map_jira_testcase_steps_to_local()`: JIRA Steps JSON → 로컬 testcase_steps
- `build_jira_testcase_steps_payload()`: 로컬 testcase_steps → JIRA Steps JSON

**Relations 매핑**
- `extract_relations_from_jira()`: JIRA issueLink → 로컬 relations

#### 특징
- RTM 버전별 JSON 구조 차이를 고려한 안전한 파싱
- HTML 태그 제거 (`<p>`, `<br>` 등)
- 복잡한 중첩 구조 처리 (stepGroups, stepColumns 등)

---

### 3.4. `gui/main_window.py` - 메인 GUI (약 10,000줄)

#### 주요 클래스

**`IssueTabWidget`** (QTabWidget)
- RTM 스타일 이슈 탭 위젯
- 탭 구성:
  - **Details**: Summary, Status, Priority, Assignee, Description, Activity, Attachments
  - **Steps**: Test Case Steps (그룹/단계 편집)
  - **Requirements**: Requirement 링크 (Test Case용)
  - **Relations**: 이슈 간 관계
  - **Test Cases**: Test Cases 목록 (Requirement/Test Plan용)
  - **Executions**: Test Execution 관리 (Test Plan/Test Execution용)
  - **Defects**: Defect 목록 (Test Execution용)

**`PanelWidget`** (QWidget)
- 좌/우 패널 공통 레이아웃
- 구성: 헤더(버튼) + 모듈 탭바 + 트리뷰 + 이슈 탭

**`MainWindow`** (QMainWindow)
- 메인 애플리케이션 윈도우
- 좌측(로컬) / 우측(온라인) 패널 분할 뷰
- 리본 툴바 (Ribbon UI)

**`JiraLoginDialog`** (QDialog)
- JIRA 설정 다이얼로그

#### 주요 기능

**로컬 패널 기능**
- 폴더/이슈 생성/삭제/이동
- 이슈 편집 및 저장
- Excel Import/Export
- 대량 이슈 생성 (로컬 → JIRA)
- 트리 뷰 (폴더/이슈 계층 구조)
- 모듈 탭: Dashboard, Requirements, Test Cases, Test Plans, Test Executions, Defects

**온라인 패널 기능**
- RTM 트리 조회 및 표시
- 온라인 이슈 상세 조회
- 온라인 이슈 생성/수정/삭제
- 온라인 → 로컬 동기화 (Pull)
- 모듈 탭별 트리 필터링

**동기화 기능**
- Pull: JIRA → 로컬 DB
- Push: 로컬 DB → JIRA
- Full Sync: 트리 구조 전체 동기화
- 동기화 모드: Server-first, Local-first, Merge

**이슈 타입별 특수 기능**
- **Test Case**: Steps 편집, Requirement 링크, Test Plan 추가
- **Test Plan**: Test Cases 관리, Execute Test Plan
- **Test Execution**: Test Case Executions 관리, Defect 링크
- **Requirement**: Test Cases Covered 표시
- **Defect**: Identifying Test Cases 표시

---

### 3.5. `backend/excel_io.py` - Excel Import/Export

#### 주요 함수

**`export_project_to_excel(conn, project_id, file_path)`**
- 프로젝트 데이터를 Excel 워크북으로 내보냄
- 시트 구성:
  - Issues: 이슈 메인 데이터
  - TestcaseSteps: Test Case Steps
  - Relations: 이슈 관계
  - TestPlanTestcases: Test Plan-Test Case 매핑
  - TestExecutions: Test Execution 메타
  - TestcaseExecutions: Test Case Execution

**`import_project_from_excel(conn, project_id, file_path)`**
- Excel 파일에서 프로젝트 데이터를 가져옴
- 컬럼 매핑: `excel_mapping.json` 기반
- jira_key 기준으로 기존 이슈 업데이트 또는 신규 생성

#### 특징
- openpyxl 라이브러리 사용 (런타임 import)
- 컬럼 이름 기반 매핑 (순서 독립적)
- Excel 매핑 설정 파일 지원

---

### 3.6. `backend/bulk_create.py` - 대량 이슈 생성

**`bulk_create_issues_in_jira(conn, issues, jira_client, project_key, progress_cb)`**
- 로컬 DB의 여러 이슈를 JIRA RTM에 일괄 생성
- 진행 상황 콜백 지원
- 성공/실패 결과 반환

---

### 3.7. `backend/sync.py` - 트리 동기화

**`sync_tree(project, client, conn, tree_types)`**
- RTM 트리 구조를 로컬 DB로 다운로드
- 폴더 및 최소한의 이슈 레코드만 생성 (상세 필드는 별도 동기화)

---

### 3.8. `gui/create_issue_dialog.py` - 온라인 이슈 생성 다이얼로그

**`CreateIssueDialog`**
- 온라인 패널에서 새 JIRA 이슈 생성
- 이슈 타입별 필드 동적 표시
- RTM API로 직접 생성

---

### 3.9. `gui/bulk_create_dialog.py` - 대량 생성 진행 다이얼로그

**`BulkCreateDialog`**
- 대량 이슈 생성 진행 상황 표시
- 진행률 바, 로그, 성공/실패 결과 테이블

---

## 4. 데이터 흐름

### 4.1. Pull (JIRA → 로컬)

```
JIRA RTM API
  └─> jira_api.JiraRTMClient.get_entity()
      └─> jira_mapping.map_rtm_to_local()
          └─> db.update_issue_fields()
              └─> SQLite issues 테이블 업데이트
```

### 4.2. Push (로컬 → JIRA)

```
로컬 DB issues 테이블
  └─> jira_mapping.build_rtm_payload()
      └─> jira_api.JiraRTMClient.create_entity() / update_entity()
          └─> JIRA RTM API
```

### 4.3. Excel Import

```
Excel 파일 (.xlsx)
  └─> excel_io.import_project_from_excel()
      └─> excel_mapping.json (컬럼 매핑)
          └─> db.create_local_issue() / update_issue_fields()
              └─> SQLite 테이블 업데이트
```

### 4.4. Excel Export

```
SQLite 테이블
  └─> excel_io.export_project_to_excel()
      └─> Excel 파일 (.xlsx) 생성
```

---

## 5. 주요 기능 요약

### 5.1. 이슈 관리
- ✅ 로컬 이슈 생성/수정/삭제
- ✅ 온라인 이슈 생성/수정/삭제
- ✅ 이슈 타입별 필드 관리 (Requirement, Test Case, Test Plan, Test Execution, Defect)
- ✅ Test Case Steps 편집
- ✅ 이슈 간 Relations 관리

### 5.2. 동기화
- ✅ Pull (JIRA → 로컬)
- ✅ Push (로컬 → JIRA)
- ✅ Full Sync (트리 구조 동기화)
- ✅ 동기화 모드 선택 (Server-first, Local-first, Merge)

### 5.3. Excel 연동
- ✅ Excel Export (프로젝트 데이터 내보내기)
- ✅ Excel Import (프로젝트 데이터 가져오기)
- ✅ 컬럼 매핑 설정 지원

### 5.4. 대량 작업
- ✅ 대량 이슈 생성 (로컬 → JIRA)
- ✅ 진행 상황 표시

### 5.5. Test Management
- ✅ Test Plan - Test Case 매핑
- ✅ Test Execution 생성 및 관리
- ✅ Test Case Execution 관리
- ✅ Step Execution 관리
- ✅ Defect 링크

---

## 6. 아키텍처 특징

### 6.1. 계층 구조
```
GUI Layer (PySide6)
    ↓
Business Logic Layer (jira_mapping, sync, bulk_create)
    ↓
Data Access Layer (db.py)
    ↓
External API Layer (jira_api.py)
    ↓
JIRA RTM REST API
```

### 6.2. 설계 원칙
- **단순성**: 외부 ORM 없이 SQLite 직접 사용
- **확장성**: 엔드포인트 템플릿 시스템으로 RTM 버전별 대응
- **유연성**: Excel 매핑 설정으로 컬럼 이름 변경 대응
- **안정성**: 스키마 마이그레이션 지원

### 6.3. 데이터 모델
- **로컬 우선**: 로컬 DB를 Single Source of Truth로 사용
- **동기화 추적**: `sync_state` 테이블로 동기화 상태 관리
- **Dirty 플래그**: 수정된 이슈 추적 (`dirty` 컬럼)

---

## 7. 현재 구현 상태

### ✅ 완료된 기능
- 기본 CRUD (Create, Read, Update, Delete)
- 트리 구조 표시 및 편집
- Excel Import/Export
- 대량 이슈 생성
- 이슈 타입별 특수 필드 처리
- Test Case Steps 편집
- Test Plan - Test Case 매핑
- Test Execution 관리
- Relations 관리

### ⚠️ 개선 필요 사항
- 온라인 패널 Save 버튼 연결 (현재 제거됨)
- Test Case Execute 기능 (현재 제거됨)
- 로컬 이슈 생성 다이얼로그 (현재 제거됨)
- 에러 처리 강화
- 동기화 충돌 해결 UI

---

## 8. 코드 통계

- **총 파일 수**: 약 18개 Python 파일
- **주요 파일 크기**:
  - `gui/main_window.py`: 약 10,000줄
  - `backend/jira_mapping.py`: 약 1,750줄
  - `backend/jira_api.py`: 약 1,000줄
  - `backend/db.py`: 약 1,100줄
  - `backend/excel_io.py`: 약 1,800줄

---

## 9. 의존성

```
PySide6      # GUI 프레임워크
requests     # HTTP 클라이언트
openpyxl     # Excel 처리 (선택적, 런타임 import)
```

---

## 10. 설정 파일

### `jira_config.json`
```json
{
  "base_url": "https://jira.example.com",
  "username": "user",
  "api_token": "token",
  "project_key": "PROJ",
  "project_id": 12345,
  "endpoints": {
    "tree_get": "/rest/rtm/1.0/api/tree/{projectId}/{treeType}",
    ...
  }
}
```

### `excel_mapping.json` (선택적)
- Excel 컬럼 이름 매핑 설정

---

## 11. 로깅

- **콘솔 로그**: INFO 레벨 (기본)
- **파일 로그**: DEBUG 레벨 (`rtm_local_manager.log`)
- **환경 변수**: `RTM_LOG_LEVEL`, `RTM_LOG_FILE`

---

## 12. 주요 이슈 및 개선 사항

### 현재 알려진 이슈
1. "Create in JIRA" 버튼 클릭 시 반응 없음 (버튼 연결 확인 필요)
2. 일부 버튼 기능 제거됨 (Save, Execute 등)
3. 로컬 이슈 생성 다이얼로그 제거됨

### 권장 개선 사항
1. 버튼 연결 상태 검증 및 수정
2. 에러 처리 및 사용자 피드백 강화
3. 동기화 충돌 해결 UI 추가
4. 단위 테스트 추가
5. 문서화 보완

---

## 13. 결론

RTM Local Manager는 JIRA RTM과 로컬 SQLite DB 간의 양방향 동기화를 지원하는 데스크톱 애플리케이션입니다. PySide6 기반의 GUI와 REST API 클라이언트, Excel 연동 기능을 통해 RTM 이슈를 효율적으로 관리할 수 있습니다.

현재 기본적인 CRUD 기능과 동기화 기능이 구현되어 있으나, 일부 버튼 연결 문제와 기능 제거로 인한 불완전한 상태입니다. 버튼 연결 검증 및 누락된 기능 복구가 필요합니다.

